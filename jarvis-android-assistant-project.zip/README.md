# J.A.R.V.I.S. Android Voice Assistant

A native Android Personal Assistant application built with **Kotlin** and **Jetpack Compose**.
Implements Android's official `VoiceInteractionService` architecture to function as a system-level digital assistant (replacing Google Assistant), with wake phrase detection for **"Jarvis"**, ElevenLabs Text-to-Speech output, and a modular AI brain ready for your **Lovable JARVIS** backend.

---

## 1. Architecture Overview

```
                        [ User Speech / Audio Stream ]
                                      │
                                      ▼
                        [ HotwordDetector ("Jarvis") ]
                                      │
              ┌───────────────────────┴───────────────────────┐
              ▼                                               ▼
  [ System Assist Gesture / Long Press ]          [ Background Wake Service ]
              │                                               │
              └───────────────────────┬───────────────────────┘
                                      ▼
                      [ JarvisVoiceInteractionService ]
                                      │
                                      ▼
                   [ JarvisVoiceInteractionSessionService ]
                                      │
                                      ▼
                     [ JarvisVoiceInteractionSession ]
                         (Visual HUD Overlay & STT)
                                      │
                  ┌───────────────────┴───────────────────┐
                  ▼                                       ▼
       [ AiBackendContract ]                     [ TtsServiceContract ]
       (LovableAiClient)                         (ElevenLabsTtsClient)
        - Zero Gemini                             - ElevenLabs API Streaming
        - Custom Webhook / REST                   - Native UK British TTS Fallback
        - Offline Stark Protocols
```

---

## 2. Explicit Android Permissions

Configured in `app/src/main/AndroidManifest.xml`:

| Permission | Purpose |
|---|---|
| `android.permission.RECORD_AUDIO` | Required to record voice input and perform speech recognition. |
| `android.permission.INTERNET` | Communicates with your Lovable AI backend and ElevenLabs TTS API. |
| `android.permission.ACCESS_NETWORK_STATE` | Detects network connectivity to gracefully toggle offline Stark heuristics. |
| `android.permission.BIND_VOICE_INTERACTION` | **Crucial:** System permission declaring JARVIS as a default voice assistant service. |
| `android.permission.FOREGROUND_SERVICE` | Keeps the wake-word detection engine active when the app is in the background. |
| `android.permission.FOREGROUND_SERVICE_MICROPHONE` | Android 14+ requirement for background microphone capture. |
| `android.permission.WAKE_LOCK` | Prevents the CPU from sleeping while processing user voice directives. |

---

## 3. How to Set JARVIS as Default Voice Assistant on Android

1. Open **Android Device Settings**.
2. Navigate to **Apps** > **Default Apps** > **Digital Assistant App** (or **Voice Input & Assist**).
3. Tap **Default digital assistant app**.
4. Select **J.A.R.V.I.S.**.
5. Long-press the Home button, swipe from the bottom corner (gesture navigation), or say *"Jarvis"* to summon the assistant.

---

## 4. Connecting Your Lovable JARVIS Project

In `com/jarvis/ai/LovableAiClient.kt`:
Update the `endpointUrl` and `bearerToken`:
```kotlin
val client = LovableAiClient(context).apply {
    endpointUrl = "https://your-lovable-project.lovable.app/api/assistant"
    bearerToken = "YOUR_LOVABLE_OR_CUSTOM_TOKEN"
}
```
The payload format expected by default:
```json
{
  "prompt": "What is the status of system protocols?",
  "client": "android-jarvis",
  "version": "1.0.0"
}
```
And returns:
```json
{
  "reply": "All systems nominal, sir."
}
```

---

## 5. Configuring ElevenLabs Text-to-Speech

In `com/jarvis/tts/ElevenLabsTtsClient.kt`:
```kotlin
val tts = ElevenLabsTtsClient(context).apply {
    apiKey = "sk_YOUR_ELEVENLABS_API_KEY"
    voiceId = "YOUR_CUSTOM_JARVIS_VOICE_ID" // e.g. Adam / Antony / Rachel
    modelId = "eleven_multilingual_v2"
}
```
*Note: If no API key is provided or the device is offline, JARVIS seamlessly falls back to Android's built-in Text-To-Speech engine with a refined British pitch and rate.*
