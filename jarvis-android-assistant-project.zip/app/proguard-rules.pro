# Add project specific ProGuard rules here.
-keep class com.jarvis.** { *; }
-keepclassmembers class com.jarvis.** { *; }
-keep class androidx.compose.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
