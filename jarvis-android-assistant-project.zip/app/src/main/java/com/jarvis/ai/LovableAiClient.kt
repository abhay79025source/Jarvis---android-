package com.jarvis.ai

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Concrete implementation connecting to your external Lovable JARVIS backend.
 *
 * Configurable via shared preferences or remote environment.
 * Includes Stark-protocol heuristic offline fallback when server is unreachable.
 * NO GEMINI IS USED.
 */
class LovableAiClient(private val context: Context) : AiBackendContract {

    private val tag = "LovableAiClient"

    // Default to local/configurable Lovable backend URL
    var endpointUrl: String = "https://your-lovable-jarvis-project.lovable.app/api/assistant"
    var bearerToken: String = ""

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    override suspend fun generateResponse(prompt: String): JarvisAiResponse {
        return withContext(Dispatchers.IO) {
            val startTime = System.currentTimeMillis()

            // If a valid Lovable endpoint is configured, make the HTTP call
            if (endpointUrl.startsWith("http://") || endpointUrl.startsWith("https://")) {
                try {
                    val jsonPayload = JSONObject().apply {
                        put("prompt", prompt)
                        put("client", "android-jarvis")
                        put("version", "1.0.0")
                    }

                    val requestBuilder = Request.Builder()
                        .url(endpointUrl)
                        .post(jsonPayload.toString().toRequestBody("application/json".toMediaType()))

                    if (bearerToken.isNotBlank()) {
                        requestBuilder.addHeader("Authorization", "Bearer $bearerToken")
                    }

                    val response = httpClient.newCall(requestBuilder.build()).execute()
                    val body = response.body?.string()

                    if (response.isSuccessful && !body.isNullOrBlank()) {
                        val parsed = JSONObject(body)
                        val replyText = parsed.optString("reply", parsed.optString("text", "At your service, sir."))
                        val latency = System.currentTimeMillis() - startTime
                        return@withContext JarvisAiResponse(
                            text = replyText,
                            latencyMs = latency,
                            source = "Remote Lovable Core"
                        )
                    }
                } catch (e: Exception) {
                    Log.w(tag, "Lovable backend query failed, switching to local Stark protocol", e)
                }
            }

            // High-fidelity Stark Heuristic Protocol Engine (Offline / Standalone fallback)
            val fallbackReply = generateStarkProtocolReply(prompt)
            val latency = System.currentTimeMillis() - startTime
            JarvisAiResponse(
                text = fallbackReply,
                latencyMs = latency,
                source = "Stark Heuristic Protocol Engine"
            )
        }
    }

    private fun generateStarkProtocolReply(prompt: String): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("status") || lower.contains("system") ->
                "All systems operational, sir. Power levels at 100 percent, telemetry nominal, and perimeter defense sensors active."

            lower.contains("who are you") || lower.contains("what are you") ->
                "I am Just A Rather Very Intelligent System. Your personal automated assistant, sir."

            lower.contains("time") ->
                "The current time is verified against atomic clock relays. Systems synchronised."

            lower.contains("protocol") ->
                "Security protocol House Party is on standby. All defensive relays configured."

            lower.contains("weather") ->
                "Atmospheric pressure is steady. Local telemetry indicates clear skies and optimal flight conditions."

            else ->
                "Understood, sir. Processing your directive: '$prompt'. Standing by for your confirmation."
        }
    }
}
