package com.jarvis.ai

/**
 * Modular Contract for JARVIS AI Brain.
 *
 * Explicitly decouples the assistant from any specific LLM.
 * NO GEMINI DEPENDENCY.
 * Connect your own Lovable JARVIS project, self-hosted LLM, or custom webhook.
 */
interface AiBackendContract {
    /**
     * Processes a user speech prompt and returns an assistant response.
     */
    suspend fun generateResponse(prompt: String): JarvisAiResponse
}

data class JarvisAiResponse(
    val text: String,
    val actionType: String = "SPEAK",
    val latencyMs: Long = 0,
    val source: String = "Lovable JARVIS Core"
)
