package com.jarvis.service

import android.app.assist.AssistContent
import android.app.assist.AssistStructure
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.voice.VoiceInteractionSession
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.jarvis.ai.AiBackendContract
import com.jarvis.ai.LovableAiClient
import com.jarvis.tts.ElevenLabsTtsClient
import com.jarvis.tts.TtsServiceContract
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Handles an active voice session when JARVIS is summoned via system assist gesture,
 * hardware button, or hotword.
 *
 * Implements:
 * 1. Visual holographic overlay floating over any current app.
 * 2. Real microphone input via Android SpeechRecognizer.
 * 3. Modular AI brain processing (Lovable JARVIS / Stark heuristics, zero Gemini).
 * 4. Spoken audio feedback via ElevenLabsTtsClient / Android TextToSpeech.
 */
class JarvisVoiceInteractionSession(context: Context) : VoiceInteractionSession(context) {

    private val tag = "JarvisSession"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val aiBrain: AiBackendContract = LovableAiClient(context)
    private val ttsEngine: TtsServiceContract = ElevenLabsTtsClient(context)

    private var speechRecognizer: SpeechRecognizer? = null
    private var overlayLayout: LinearLayout? = null
    private var statusTextView: TextView? = null
    private var transcriptTextView: TextView? = null
    private var responseTextView: TextView? = null

    override fun onCreate() {
        super.onCreate()
        Log.d(tag, "JARVIS VoiceInteractionSession created.")
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        Log.d(tag, "JARVIS Session shown. Trigger flags: $showFlags")

        ttsEngine.playRecognitionChime()
        startVoiceCommandCapture()
    }

    override fun onCreateContentView(): View {
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(40, 40, 40, 40)

            val background = GradientDrawable().apply {
                setColor(Color.parseColor("#E6030811")) // 90% opacity dark
                cornerRadius = 32f
                setStroke(3, Color.parseColor("#00F0FF"))
            }
            this.background = background
        }

        val titleView = TextView(context).apply {
            text = "J.A.R.V.I.S. VOICE INTERACTION"
            setTextColor(Color.parseColor("#00F0FF"))
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 16)
        }
        root.addView(titleView)

        statusTextView = TextView(context).apply {
            text = "LISTENING FOR DIRECTIVE..."
            setTextColor(Color.parseColor("#00808F"))
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 16)
        }
        root.addView(statusTextView)

        transcriptTextView = TextView(context).apply {
            text = ""
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 16)
        }
        root.addView(transcriptTextView)

        responseTextView = TextView(context).apply {
            text = ""
            setTextColor(Color.parseColor("#C9E9FF"))
            textSize = 13f
            gravity = Gravity.CENTER
        }
        root.addView(responseTextView)

        overlayLayout = root
        return root
    }

    private fun startVoiceCommandCapture() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            statusTextView?.text = "Speech recognizer unavailable"
            mainHandler.postDelayed({ finish() }, 2000)
            return
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    statusTextView?.text = "STATUS: LISTENING..."
                }

                override fun onBeginningOfSpeech() {
                    statusTextView?.text = "STATUS: CAPTURING AUDIO..."
                }

                override fun onRmsChanged(rmsdB: Float) {}

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    statusTextView?.text = "STATUS: PROCESSING..."
                }

                override fun onError(error: Int) {
                    statusTextView?.text = "Error code: $error"
                    mainHandler.postDelayed({ finish() }, 2000)
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spokenText = matches?.firstOrNull() ?: ""
                    if (spokenText.isNotBlank()) {
                        transcriptTextView?.text = "\"$spokenText\""
                        processUserQuery(spokenText)
                    } else {
                        finish()
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val interim = matches?.firstOrNull() ?: ""
                    if (interim.isNotBlank()) {
                        transcriptTextView?.text = "\"$interim\""
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        speechRecognizer?.startListening(intent)
    }

    private fun processUserQuery(query: String) {
        statusTextView?.text = "STATUS: QUERYING AI BRAIN..."
        scope.launch {
            try {
                val response = aiBrain.generateResponse(query)
                statusTextView?.text = "STATUS: SPEAKING..."
                responseTextView?.text = response.text

                ttsEngine.speak(response.text) {
                    mainHandler.postDelayed({ finish() }, 1500)
                }
            } catch (e: Exception) {
                Log.e(tag, "Error processing query in JARVIS core", e)
                val fallback = "Apologies sir, I encountered an issue accessing the neural backend."
                responseTextView?.text = fallback
                ttsEngine.speak(fallback) {
                    mainHandler.postDelayed({ finish() }, 1500)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer?.destroy()
        speechRecognizer = null
        ttsEngine.stop()
        scope.cancel()
        Log.d(tag, "JARVIS Session destroyed.")
    }
}
