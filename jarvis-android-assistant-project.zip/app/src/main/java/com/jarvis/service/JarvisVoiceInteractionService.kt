package com.jarvis.service

import android.content.Intent
import android.os.Bundle
import android.service.voice.AlwaysOnHotwordDetector
import android.service.voice.VoiceInteractionService
import android.util.Log
import com.jarvis.wake.HotwordDetector
import java.util.Locale

/**
 * Core Android VoiceInteractionService.
 *
 * Registered in AndroidManifest.xml with BIND_VOICE_INTERACTION permission.
 * Enables JARVIS to act as the primary Android Digital Assistant (replacing Google Assistant).
 */
class JarvisVoiceInteractionService : VoiceInteractionService() {

    private val tag = "JarvisVoiceService"
    private var hotwordDetector: HotwordDetector? = null

    override fun onReady() {
        super.onReady()
        Log.i(tag, "JARVIS VoiceInteractionService is READY.")
        
        // Initialize hotword detection for wake phrase "Jarvis"
        setupWakeWordDetection()
    }

    override fun onShutdown() {
        super.onShutdown()
        hotwordDetector?.stopListening()
        Log.i(tag, "JARVIS VoiceInteractionService shutdown.")
    }

    private fun setupWakeWordDetection() {
        hotwordDetector = HotwordDetector(
            context = this,
            onWakeWordDetected = { wakePhrase ->
                Log.d(tag, "Wake phrase '$wakePhrase' triggered! Launching session...")
                launchSession()
            }
        )
        hotwordDetector?.startListening()
    }

    private fun launchSession() {
        val args = Bundle().apply {
            putString("trigger", "wake_phrase")
            putLong("timestamp", System.currentTimeMillis())
        }
        showSession(args, SHOW_SOURCE_ASSIST_GESTURE)
    }

    override fun onGetSupportedVoiceActions(voiceActions: Set<String>): Set<String> {
        Log.d(tag, "Querying supported voice actions: $voiceActions")
        return voiceActions
    }
}
