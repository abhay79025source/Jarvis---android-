package com.jarvis.service

import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import android.util.Log

/**
 * Android RecognitionService implementation for JARVIS.
 * Allows other apps or Android system components to use JARVIS as the Speech-To-Text engine.
 */
class JarvisRecognitionService : RecognitionService() {

    private val tag = "JarvisRecognition"
    private var currentListener: Callback? = null

    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        Log.d(tag, "RecognitionService started listening")
        currentListener = listener
        listener?.beginningOfSpeech()
        listener?.readyForSpeech(Bundle())
    }

    override fun onStopListening(listener: Callback?) {
        Log.d(tag, "RecognitionService stopped listening")
        listener?.endOfSpeech()

        // Return empty or acknowledge results to avoid hanging the calling client
        val results = Bundle().apply {
            putStringArrayList(
                SpeechRecognizer.RESULTS_RECOGNITION,
                arrayListOf("Jarvis directive acknowledged")
            )
        }
        listener?.results(results)
    }

    override fun onCancel(listener: Callback?) {
        Log.d(tag, "RecognitionService cancelled")
        currentListener = null
    }

    override fun onDestroy() {
        super.onDestroy()
        currentListener = null
    }
}
