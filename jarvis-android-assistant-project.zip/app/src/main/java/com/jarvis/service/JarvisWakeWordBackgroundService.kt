package com.jarvis.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.jarvis.JarvisApplication
import com.jarvis.MainActivity
import com.jarvis.wake.HotwordDetector

/**
 * Foreground Service running with FOREGROUND_SERVICE_MICROPHONE permission.
 * Ensures that even when the screen is locked or another app is open,
 * JARVIS actively listens for the wake phrase "Jarvis".
 */
class JarvisWakeWordBackgroundService : Service() {

    private val tag = "JarvisWakeService"
    private var hotwordDetector: HotwordDetector? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) { // Android 14+
                startForeground(
                    NOTIFICATION_ID,
                    createForegroundNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) { // Android 10+
                startForeground(
                    NOTIFICATION_ID,
                    createForegroundNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIFICATION_ID, createForegroundNotification())
            }
        } catch (e: Exception) {
            Log.e(tag, "Failed to start foreground service with microphone type", e)
        }

        hotwordDetector = HotwordDetector(
            context = this,
            onWakeWordDetected = {
                Log.d(tag, "Wake phrase detected in background service! Launching JARVIS...")
                val intent = Intent(this, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("AUTO_LISTEN", true)
                }
                startActivity(intent)
            }
        )
        hotwordDetector?.startListening()
    }

    private fun createForegroundNotification(): Notification {
        val launchIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, JarvisApplication.WAKE_CHANNEL_ID)
            .setContentTitle("JARVIS Voice Engine Active")
            .setContentText("Awaiting wake phrase: 'Jarvis'")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        hotwordDetector?.stopListening()
        Log.d(tag, "JARVIS background wake service destroyed.")
    }

    companion object {
        private const val NOTIFICATION_ID = 1001
    }
}
