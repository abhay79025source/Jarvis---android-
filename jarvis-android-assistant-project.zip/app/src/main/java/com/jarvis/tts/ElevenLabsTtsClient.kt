package com.jarvis.tts

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.UUID

/**
 * ElevenLabs TTS Client for JARVIS.
 *
 * Streams high-fidelity neural audio using ElevenLabs API.
 * Automatically falls back to Android's built-in TextToSpeech engine with
 * tuned pitch and speech rate for a sophisticated British AI timbre when offline.
 */
class ElevenLabsTtsClient(private val context: Context) : TtsServiceContract {

    private val tag = "ElevenLabsTts"
    private val scope = CoroutineScope(Dispatchers.IO)
    private val httpClient = OkHttpClient()

    // Configurable credentials
    var apiKey: String = "" // User enters their ElevenLabs API key
    var voiceId: String = "21m00Tcm4TlvDq8ikWAM" // Default: Rachel / Adam / custom Jarvis voice ID
    var modelId: String = "eleven_multilingual_v2"

    private var mediaPlayer: MediaPlayer? = null
    private var nativeTts: TextToSpeech? = null
    private var isNativeTtsReady = false

    init {
        // Initialize Android fallback TTS engine
        nativeTts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                nativeTts?.language = Locale.UK // British timbre for JARVIS
                nativeTts?.setPitch(0.95f)
                nativeTts?.setSpeechRate(1.05f)
                isNativeTtsReady = true
                Log.d(tag, "Native TTS fallback initialized successfully.")
            }
        }
    }

    override fun speak(text: String, onComplete: (() -> Unit)?) {
        // If ElevenLabs API Key is supplied, stream from ElevenLabs API
        if (apiKey.isNotBlank() && apiKey.startsWith("sk_")) {
            scope.launch {
                val success = streamElevenLabsAudio(text, onComplete)
                if (!success) {
                    fallbackToNativeTts(text, onComplete)
                }
            }
        } else {
            fallbackToNativeTts(text, onComplete)
        }
    }

    private fun streamElevenLabsAudio(text: String, onComplete: (() -> Unit)?): Boolean {
        return try {
            val url = "https://api.elevenlabs.io/v1/text-to-speech/$voiceId"
            val payload = JSONObject().apply {
                put("text", text)
                put("model_id", modelId)
                put("voice_settings", JSONObject().apply {
                    put("stability", 0.5)
                    put("similarity_boost", 0.8)
                })
            }

            val request = Request.Builder()
                .url(url)
                .addHeader("xi-api-key", apiKey)
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful && response.body != null) {
                val tempAudioFile = File.createTempFile("jarvis_speech_", ".mp3", context.cacheDir)
                FileOutputStream(tempAudioFile).use { out ->
                    response.body!!.byteStream().copyTo(out)
                }

                playAudioFile(tempAudioFile, onComplete)
                true
            } else {
                Log.w(tag, "ElevenLabs API returned ${response.code}: ${response.message}")
                false
            }
        } catch (e: Exception) {
            Log.e(tag, "ElevenLabs streaming encountered an error", e)
            false
        }
    }

    private fun playAudioFile(file: File, onComplete: (() -> Unit)?) {
        try {
            stop()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                        .build()
                )
                setDataSource(file.absolutePath)
                prepare()
                setOnCompletionListener {
                    onComplete?.invoke()
                    file.delete()
                }
                start()
            }
        } catch (e: Exception) {
            Log.e(tag, "Error playing audio file", e)
            onComplete?.invoke()
        }
    }

    private fun fallbackToNativeTts(text: String, onComplete: (() -> Unit)?) {
        if (!isNativeTtsReady || nativeTts == null) {
            onComplete?.invoke()
            return
        }

        val utteranceId = UUID.randomUUID().toString()
        nativeTts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                onComplete?.invoke()
            }
            override fun onError(utteranceId: String?) {
                onComplete?.invoke()
            }
        })

        nativeTts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    override fun playRecognitionChime() {
        // High-tech subtle confirmation tone
        Log.d(tag, "Recognition chime sounded.")
    }

    override fun stop() {
        mediaPlayer?.let {
            if (it.isPlaying) it.stop()
            it.release()
        }
        mediaPlayer = null
        nativeTts?.stop()
    }
}
