package com.jarvis.tts

/**
 * Modular Contract for Text-to-Speech Engine.
 * Supports ElevenLabs cloud streaming and Android native TTS fallback.
 */
interface TtsServiceContract {
    /**
     * Synthesizes and plays the spoken response.
     */
    fun speak(text: String, onComplete: (() -> Unit)? = null)

    /**
     * Plays a high-tech UI recognition chime.
     */
    fun playRecognitionChime()

    /**
     * Immediately stops active speech playback.
     */
    fun stop()
}
