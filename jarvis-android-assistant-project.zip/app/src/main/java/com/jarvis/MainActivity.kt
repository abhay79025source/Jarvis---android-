package com.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.jarvis.ai.AiBackendContract
import com.jarvis.ai.LovableAiClient
import com.jarvis.service.JarvisWakeWordBackgroundService
import com.jarvis.tts.ElevenLabsTtsClient
import com.jarvis.tts.TtsServiceContract
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Native Jetpack Compose HUD Activity for JARVIS.
 *
 * Implements:
 * 1. Real microphone capture via Android SpeechRecognizer.
 * 2. Real text-to-speech spoken responses via ElevenLabsTtsClient / Android TextToSpeech.
 * 3. Modular AI brain integration (LovableAiClient + offline Stark heuristics, zero Gemini).
 * 4. Runtime RECORD_AUDIO permission flow.
 * 5. Holographic Arc Reactor futuristic interface.
 */
class MainActivity : ComponentActivity() {

    private lateinit var ttsEngine: TtsServiceContract
    private lateinit var aiBrain: AiBackendContract

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ttsEngine = ElevenLabsTtsClient(this)
        aiBrain = LovableAiClient(this)

        val autoListen = intent?.getBooleanExtra("AUTO_LISTEN", false) ?: false

        setContent {
            JarvisTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF030811)
                ) {
                    JarvisHudScreen(
                        ttsEngine = ttsEngine,
                        aiBrain = aiBrain,
                        autoListen = autoListen
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ttsEngine.stop()
    }
}

enum class JarvisState {
    IDLE, LISTENING, PROCESSING, SPEAKING
}

@Composable
fun JarvisHudScreen(
    ttsEngine: TtsServiceContract,
    aiBrain: AiBackendContract,
    autoListen: Boolean = false
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var jarvisState by remember { mutableStateOf(JarvisState.IDLE) }
    var transcript by remember { mutableStateOf("") }
    var interimTranscript by remember { mutableStateOf("") }
    var responseText by remember { mutableStateOf("") }
    var inputQuery by remember { mutableStateOf("") }
    var audioRmsLevel by remember { mutableStateOf(0f) }

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    // SpeechRecognizer instance
    var speechRecognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }

    // Clean up SpeechRecognizer on dispose
    DisposableEffect(Unit) {
        val recognizer = if (SpeechRecognizer.isRecognitionAvailable(context)) {
            SpeechRecognizer.createSpeechRecognizer(context)
        } else {
            null
        }
        speechRecognizer = recognizer

        onDispose {
            recognizer?.destroy()
        }
    }

    fun stopAssistant() {
        speechRecognizer?.stopListening()
        ttsEngine.stop()
        jarvisState = JarvisState.IDLE
    }

    fun processDirective(queryText: String) {
        if (queryText.isBlank()) {
            jarvisState = JarvisState.IDLE
            return
        }

        jarvisState = JarvisState.PROCESSING
        transcript = queryText
        interimTranscript = ""

        coroutineScope.launch {
            try {
                val aiResponse = aiBrain.generateResponse(queryText)
                responseText = aiResponse.text
                jarvisState = JarvisState.SPEAKING

                ttsEngine.speak(aiResponse.text) {
                    jarvisState = JarvisState.IDLE
                }
            } catch (e: Exception) {
                Log.e("JarvisHUD", "Directive processing failed", e)
                val fallback = "Apologies sir, an internal error occurred in the neural interface."
                responseText = fallback
                jarvisState = JarvisState.SPEAKING
                ttsEngine.speak(fallback) {
                    jarvisState = JarvisState.IDLE
                }
            }
        }
    }

    fun startListening() {
        if (!hasMicPermission) {
            Toast.makeText(context, "Microphone permission required", Toast.LENGTH_SHORT).show()
            return
        }

        ttsEngine.stop()
        val recognizer = speechRecognizer
        if (recognizer == null) {
            Toast.makeText(context, "Speech recognition not available on this device", Toast.LENGTH_LONG).show()
            return
        }

        jarvisState = JarvisState.LISTENING
        transcript = ""
        interimTranscript = ""
        ttsEngine.playRecognitionChime()

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                jarvisState = JarvisState.LISTENING
            }

            override fun onBeginningOfSpeech() {
                jarvisState = JarvisState.LISTENING
            }

            override fun onRmsChanged(rmsdB: Float) {
                audioRmsLevel = rmsdB
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                jarvisState = JarvisState.PROCESSING
            }

            override fun onError(error: Int) {
                audioRmsLevel = 0f
                val errorMessage = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Please try again."
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Listening timed out."
                    SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission denied."
                    else -> "Recognition error: code $error"
                }
                Log.w("JarvisHUD", errorMessage)
                if (jarvisState == JarvisState.LISTENING) {
                    jarvisState = JarvisState.IDLE
                }
            }

            override fun onResults(results: Bundle?) {
                audioRmsLevel = 0f
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spokenText = matches?.firstOrNull() ?: ""
                if (spokenText.isNotBlank()) {
                    processDirective(spokenText)
                } else {
                    jarvisState = JarvisState.IDLE
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                interimTranscript = matches?.firstOrNull() ?: ""
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        try {
            recognizer.startListening(intent)
        } catch (e: Exception) {
            Log.e("JarvisHUD", "Failed to start speech recognizer", e)
            jarvisState = JarvisState.IDLE
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasMicPermission = isGranted
        if (isGranted) {
            val serviceIntent = Intent(context, JarvisWakeWordBackgroundService::class.java)
            try {
                context.startForegroundService(serviceIntent)
            } catch (e: Exception) {
                Log.w("JarvisHUD", "Could not start wake-word foreground service", e)
            }
            startListening()
        }
    }

    // Auto-listen if launched via hotword or assist gesture
    LaunchedEffect(autoListen) {
        if (autoListen && hasMicPermission) {
            startListening()
        }
    }

    // Animation controllers for concentric holographic rings
    val infiniteTransition = rememberInfiniteTransition(label = "rings")
    val outerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(22000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outerRing"
    )

    val innerRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(14000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "innerRing"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // TOP TELEMETRY BAR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertizontally
        ) {
            Column {
                Text(
                    text = "J.A.R.V.I.S. MK-85",
                    color = Color(0xFF00F0FF),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "VOICE INTERACTION CORE // SYSTEM ASSISTANT",
                    color = Color(0xFF00808F),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            IconButton(
                onClick = {
                    val intent = Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)
                    context.startActivity(intent)
                }
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Voice Input Settings",
                    tint = Color(0xFF00F0FF)
                )
            }
        }

        // HOLOGRAPHIC ARC REACTOR CORE
        Box(
            modifier = Modifier
                .size(260.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2, size.height / 2)
                val radius = size.minDimension / 2

                drawCircle(
                    color = Color(0xFF00F0FF).copy(alpha = 0.2f),
                    radius = radius - 6.dp.toPx(),
                    style = Stroke(width = 1.5.dp.toPx())
                )

                drawCircle(
                    color = Color(0xFF0077FF).copy(alpha = 0.35f),
                    radius = radius - 20.dp.toPx(),
                    style = Stroke(
                        width = 2.5.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                )
            }

            // Outer rotating ring
            Box(
                modifier = Modifier
                    .size(230.dp)
                    .rotate(outerRotation)
                    .border(
                        width = 2.dp,
                        brush = Brush.sweepGradient(
                            listOf(
                                Color(0xFF00F0FF),
                                Color.Transparent,
                                Color(0xFF0077FF),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )

            // Inner counter-rotating ring
            Box(
                modifier = Modifier
                    .size(180.dp)
                    .rotate(innerRotation)
                    .border(
                        width = 1.5.dp,
                        brush = Brush.sweepGradient(
                            listOf(
                                Color.Transparent,
                                Color(0xFF00F0FF),
                                Color.Transparent,
                                Color(0xFFFFAA00)
                            )
                        ),
                        shape = CircleShape
                    )
            )

            // Center Orb Button
            Box(
                modifier = Modifier
                    .size(110.dp)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                when (jarvisState) {
                                    JarvisState.IDLE -> Color(0x3300F0FF)
                                    JarvisState.LISTENING -> Color(0x9900F0FF)
                                    JarvisState.PROCESSING -> Color(0x99FFAA00)
                                    JarvisState.SPEAKING -> Color(0x990077FF)
                                },
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
                    .border(
                        width = 2.dp,
                        color = Color(0xFF00F0FF).copy(alpha = 0.8f),
                        shape = CircleShape
                    )
                    .clickable {
                        if (!hasMicPermission) {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        } else {
                            if (jarvisState == JarvisState.LISTENING) {
                                stopAssistant()
                            } else {
                                startListening()
                            }
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                if (jarvisState == JarvisState.LISTENING) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "Stop",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Start Voice Input",
                        tint = if (jarvisState == JarvisState.SPEAKING) Color(0xFF0077FF) else Color(0xFF00F0FF),
                        modifier = Modifier.size(36.dp)
                    )
                }
            }
        }

        // TELEMETRY & TRANSCRIPT PANEL
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF071324), RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFF00F0FF).copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = when (jarvisState) {
                    JarvisState.IDLE -> "STATUS: AWAITING INPUT // SAY 'JARVIS' OR TAP MIC"
                    JarvisState.LISTENING -> "STATUS: AUDIO STREAM ACTIVE... (SPEAK NOW)"
                    JarvisState.PROCESSING -> "STATUS: QUERYING MODULAR AI BACKEND..."
                    JarvisState.SPEAKING -> "STATUS: VOCAL SYNTHESIS ACTIVE"
                },
                color = when (jarvisState) {
                    JarvisState.IDLE -> Color(0xFF00808F)
                    JarvisState.LISTENING -> Color(0xFF00F0FF)
                    JarvisState.PROCESSING -> Color(0xFFFFAA00)
                    JarvisState.SPEAKING -> Color(0xFF0077FF)
                },
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Real spoken interim or final text
            val currentText = if (interimTranscript.isNotBlank()) interimTranscript else transcript
            if (currentText.isNotBlank()) {
                Text(
                    text = "\"$currentText\"",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Center
                )
            }

            if (responseText.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = responseText,
                    color = Color(0xFFC9E9FF),
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Center
                )
            }
        }

        // TEXT DIRECTIVE INPUT & CONTROLS
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertizontally,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = inputQuery,
                    onValueChange = { inputQuery = it },
                    placeholder = {
                        Text(
                            text = "Type directive...",
                            color = Color(0xFF00808F),
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF00F0FF),
                        unfocusedBorderColor = Color(0xFF00808F),
                        focusedTextColor = Color(0xFFC9E9FF),
                        unfocusedTextColor = Color(0xFFC9E9FF),
                        cursorColor = Color(0xFF00F0FF)
                    ),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                Button(
                    onClick = {
                        if (inputQuery.isNotBlank()) {
                            val q = inputQuery
                            inputQuery = ""
                            processDirective(q)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = Color.Black
                    )
                }
            }

            // Permission notification
            if (!hasMicPermission) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0x33FFAA00)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertizontally
                    ) {
                        Text(
                            text = "Microphone permission required for voice",
                            color = Color(0xFFFFAA00),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Button(
                            onClick = { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFAA00))
                        ) {
                            Text("Grant", color = Color.Black, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF00F0FF),
            secondary = Color(0xFF0077FF),
            background = Color(0xFF030811),
            surface = Color(0xFF071324)
        ),
        content = content
    )
}
